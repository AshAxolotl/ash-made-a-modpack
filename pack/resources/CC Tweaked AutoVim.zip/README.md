# Makes it so that a vim-like editor is installed by default in all cc: tweaked computer's rom.
